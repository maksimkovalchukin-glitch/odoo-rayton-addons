# Rayton Project Hub — Odoo 17 Community

Єдиний модуль для ініціювання проектів з CRM нагод + боковий чат у задачах.

---

## Що робить

### 1. Кнопка "🚀 Ініціювати проект" у CRM нагоді
- З'являється в шапці форми нагоди
- Відкриває wizard з вибором шаблону

### 2. Wizard з 3 типами проектів
| Вибір | Шаблон |
|-------|--------|
| СЕС | project.project з назвою "СЕС" |
| УЗЕ | project.project з назвою "УЗЕ" |
| СЕС+УЗЕ | project.project з назвою "СЕС+УЗЕ" |

### 3. Автоматично при підтвердженні
1. Копіює проект з шаблону → назва: `{Назва нагоди} [{Тип}]`
2. Створює канал Discuss з такою ж назвою
3. Прив'язує канал до проекту (`discuss_channel_id`)
4. Позначає нагоду як ініційовану, записує зв'язок
5. Надсилає **вебхук** на `https://n8n.rayton.net/webhook/ca5cf6c3-...`

### 4. Payload вебхука (→ n8n → Telegram)
```json
{
  "event": "project_initiated",
  "project": { "id": 42, "name": "нагода - тест [СЕС]", "template_type": "ses" },
  "channel": { "id": 17, "name": "нагода - тест [СЕС]", "uuid": "abc-123" },
  "initiator": { "id": 3, "name": "RAYTON Admin", "login": "admin", "email": "..." },
  "crm_lead": { "id": 5, "name": "нагода - тест" }
}
```

### 5. Бокова панель чату в задачах проекту
- Фіолетова кнопка "💬 Чат" справа на сторінці задач
- Виїзна панель 390px з повідомленнями каналу
- Вбудований composer — надсилати без виходу зі сторінки
- Ширину змінювати перетягуванням лівого краю
- Посилання на повне вікно Discuss

---

## Встановлення

### Підготовка шаблонів проектів
Перед встановленням переконайтеся, що в Odoo існують шаблонні проекти з назвами:
- `СЕС`
- `УЗЕ`
- `СЕС+УЗЕ`

Якщо шаблонів немає — проект буде створено порожнім з правильною назвою.

### Кроки
```bash
# 1. Скопіюйте папку в addons
cp -r rayton_project_hub /path/to/odoo/addons/

# 2. Оновіть список модулів
Settings → Technical → Update Module List

# 3. Знайдіть "Rayton Project Hub" і встановіть
```

---

## Структура

```
rayton_project_hub/
├── __manifest__.py
├── __init__.py
├── models/
│   ├── crm_lead.py              ← поле project_id, кнопка action_initiate_project
│   └── project_project.py       ← discuss_channel_id, _send_webhook()
├── wizard/
│   ├── project_initiate_wizard.py      ← вся бізнес-логіка
│   └── project_initiate_wizard_views.xml
├── views/
│   ├── crm_lead_views.xml       ← кнопка в шапці нагоди
│   └── project_views.xml        ← поле каналу у формі проекту
├── security/
│   └── ir.model.access.csv
└── static/src/
    ├── css/discussion_panel.css
    ├── xml/discussion_panel.xml  ← OWL шаблони
    └── js/discussion_panel.js    ← patch ListController, RaytonPanelManager
```

---

## Налаштування

У `models/project_project.py` змінити URL вебхука:
```python
WEBHOOK_URL = "https://n8n.rayton.net/webhook/ca5cf6c3-a92e-470a-8af1-38b14b0ffff7"
```
